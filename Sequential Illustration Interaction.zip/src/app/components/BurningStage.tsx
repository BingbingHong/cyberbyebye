import { useEffect } from "react";
import imgFrame5 from "figma:asset/2edbb4b2d19fc6361b41e82bfd9990d7b801a39f.png";
import img1 from "figma:asset/aa6dd4bd03ca46c92209d8c3334ad7a81ac30a74.png";
import img2 from "figma:asset/60d7327f6669d5ae5d7287d52c1c76a53e78e4ed.png";
import img3 from "figma:asset/f8d2a40c925b11141803917dff2933e19e614965.png";

function Frame() {
  return (
    <div className="absolute left-[33px] pointer-events-none rounded-[100px] size-[50px] top-[45px]">
      <div className="absolute inset-0 overflow-hidden rounded-[100px]">
        <img alt="" className="absolute left-[-20.8%] max-w-none size-[134.07%] top-[-13.04%]" src={imgFrame5} />
      </div>
      <div aria-hidden="true" className="absolute border-[#676767] border-[3px] border-solid inset-0 rounded-[100px]" />
    </div>
  );
}

function Frame1() {
  return <div className="absolute bg-[#0dbf22] left-[70px] rounded-[100px] size-[12px] top-[83px]" />;
}

function Group() {
  return (
    <div className="absolute h-[120px] left-[712px] top-[569px] w-0">
      <div className="absolute inset-[0_-4px_0_0]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 4.00001 120">
          <g id="Group 4">
            <line id="Line 2" stroke="var(--stroke-0, #FBC4D4)" strokeWidth="4" x1="2.00001" x2="2" y1="8.74228e-08" y2="120" />
            <line id="Line 3" stroke="var(--stroke-0, #FF6444)" strokeWidth="4" x1="2.00001" x2="2" y1="8.74228e-08" y2="13" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Group1() {
  return (
    <div className="h-[120px] relative w-[27px]">
      <div className="absolute inset-[0_-14.81%_0_0]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 31 120">
          <g id="Group 5">
            <line id="Line 2" stroke="var(--stroke-0, #FBC4D4)" strokeWidth="4" transform="matrix(-0.219512 0.97561 -1 0 27 0)" x2="123" y1="-2" y2="-2" />
            <line id="Line 3" stroke="var(--stroke-0, #FF6444)" strokeWidth="4" transform="matrix(-0.219512 0.97561 -1 0 27 0)" x2="13.325" y1="-2" y2="-2" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Group2() {
  return (
    <div className="absolute h-[120px] left-[726px] top-[569px] w-[27px]">
      <div className="absolute inset-[0_-14.81%_0_0]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 31 120">
          <g id="Group 6">
            <line id="Line 2" stroke="var(--stroke-0, #FBC4D4)" strokeWidth="4" transform="matrix(-0.219512 0.97561 -1 0 27 0)" x2="123" y1="-2" y2="-2" />
            <line id="Line 3" stroke="var(--stroke-0, #FF6444)" strokeWidth="4" transform="matrix(-0.219512 0.97561 -1 0 27 0)" x2="13.325" y1="-2" y2="-2" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Group3() {
  return (
    <div className="absolute contents left-[572px] top-[569px]">
      <Group />
      <div className="absolute flex h-[120px] items-center justify-center left-[671px] top-[569px] w-[27px]">
        <div className="flex-none rotate-[180deg] scale-y-[-100%]">
          <Group1 />
        </div>
      </div>
      <Group2 />
      <div className="absolute h-[248px] left-[calc(50%-0.5px)] top-[598px] translate-x-[-50%] w-[295px]" data-name="炉子 1">
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
          <img alt="" className="max-w-full max-h-full object-contain" src={img1} />
        </div>
      </div>
    </div>
  );
}

interface BurningStageProps {
  onComplete: () => void;
}

export default function BurningStage({ onComplete }: BurningStageProps) {
  useEffect(() => {
    // Wait for a few seconds then transition
    const timer = setTimeout(() => {
      onComplete();
    }, 3000);
    return () => clearTimeout(timer);
  }, [onComplete]);

  return (
    <div className="relative w-[1440px] h-[1024px] bg-white overflow-hidden" data-name="Desktop - 7" style={{ backgroundImage: "linear-gradient(rgba(251, 196, 212, 0) 9.668%, rgb(251, 196, 212) 114.31%), linear-gradient(90deg, rgb(255, 255, 255) 0%, rgb(255, 255, 255) 100%)" }}>
      <div className="absolute h-[598px] left-[372px] top-0 w-[695px]" data-name="云 1">
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <img alt="" className="absolute h-[116.18%] left-0 max-w-none top-0 w-full" src={img2} />
        </div>
      </div>
      <p className="absolute font-['HYXueJunJ:Regular',sans-serif] leading-[normal] left-[86px] not-italic text-[256px] text-nowrap text-white top-[256px] tracking-[81.92px]">老爷保号</p>
      <div className="absolute left-1/2 size-[464px] top-[71px] translate-x-[-50%]" data-name="老爷像 1">
        <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none size-full" src={img3} />
      </div>
      <p className="absolute font-['HYXiaoBoMeiYanTiW:Regular',sans-serif] leading-[normal] left-[101px] not-italic text-[36px] text-black text-nowrap top-[52px] tracking-[4.32px]">老爷</p>
      <Frame />
      <Frame1 />
      <p className="absolute font-['HYXiaoBoMeiYanTiW:Regular',sans-serif] leading-[normal] left-[calc(50%-170px)] not-italic text-[24px] text-black text-nowrap top-[876px] tracking-[7.68px]">“上三柱香，默念愿望”</p>
      <Group3 />
    </div>
  );
}
