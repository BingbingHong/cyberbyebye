import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import imgFrame5 from "figma:asset/2edbb4b2d19fc6361b41e82bfd9990d7b801a39f.png";
import img1 from "figma:asset/4c8ca258965195e005665de314617809caf91d62.png";
import img2 from "figma:asset/6c818d9a51263ec3460aa419fc2edaa45de7e183.png";
import img3 from "figma:asset/4da855e42a9ec9815149284aff9517df5ad06bce.png";
import img4 from "figma:asset/60d7327f6669d5ae5d7287d52c1c76a53e78e4ed.png";
import img5 from "figma:asset/f8d2a40c925b11141803917dff2933e19e614965.png";

// --- Components from Desktop5.tsx ---

function Avatar() {
  return (
    <div className="absolute left-[33px] pointer-events-none rounded-[100px] size-[50px] top-[45px]">
      <div className="absolute inset-0 overflow-hidden rounded-[100px]">
        <img alt="" className="absolute left-[-20.8%] max-w-none size-[134.07%] top-[-13.04%]" src={imgFrame5} />
      </div>
      <div aria-hidden="true" className="absolute border-[#676767] border-[3px] border-solid inset-0 rounded-[100px]" />
    </div>
  );
}

function StatusDot() {
  return <div className="absolute bg-[#0dbf22] left-[70px] rounded-[100px] size-[12px] top-[83px]" />;
}

// Left Offering Content (Red Peach Cake)
function LeftOfferingContent() {
  return (
    <div className="absolute contents left-[27px] top-[7px]">
      <div className="absolute contents left-[27px] top-[7px]">
        <div className="absolute flex h-[130.938px] items-center justify-center left-[33.75px] top-[15.56px] w-[123.251px]" style={{ "--transform-inner-width": "0", "--transform-inner-height": "0" } as React.CSSProperties}>
          <div className="flex-none rotate-[31.852deg]">
            <div className="h-[104.236px] opacity-80 relative w-[80.341px]" data-name="红桃粿 1">
              <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none size-full" src={img1} />
            </div>
          </div>
        </div>
        <div className="absolute flex h-[108.328px] items-center justify-center left-[27px] top-[7px] w-[85.727px]" style={{ "--transform-inner-width": "0", "--transform-inner-height": "0" } as React.CSSProperties}>
          <div className="flex-none rotate-[3.023deg]">
            <div className="h-[104.236px] relative w-[80.341px]" data-name="红桃粿 2">
              <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none size-full" src={img1} />
            </div>
          </div>
        </div>
      </div>
      <div className="absolute contents left-[47px] top-[125px]">
        <p className="absolute font-['HYZhangZiShanTiW:Regular',sans-serif] leading-[normal] left-[47px] not-italic text-[24px] text-black text-nowrap top-[126px] tracking-[2.88px]">{`红桃 `}</p>
        <div className="absolute contents font-['HYZhangZiShanTiW:Regular',sans-serif] leading-[normal] left-[96px] not-italic text-[24px] text-black text-nowrap top-[125px]">
          <p className="absolute left-[96px] top-[126px]">米</p>
          <p className="absolute left-[108px] top-[125px]">果</p>
        </div>
      </div>
    </div>
  );
}

// Center Offering Content (Tea)
function CenterOfferingContent() {
  return (
    <div className="flex items-center justify-center w-full h-full">
        <img alt="茶" className="w-[60%] h-auto object-contain" src={img2} />
    </div>
  );
}

// Right Offering Content (Apple)
function RightOfferingContent() {
  return (
    <div className="flex items-center justify-center w-full h-full">
        <img alt="苹果" className="w-[50%] h-auto object-contain" src={img3} />
    </div>
  );
}

function DoneButton({ onClick }: { onClick: () => void }) {
  return (
    <motion.button
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      onClick={onClick}
      className="absolute left-[calc(50%+0.5px)] rounded-[32px] top-[842px] translate-x-[-50%] w-[281px] cursor-pointer hover:bg-black/5 transition-colors"
    >
      <div className="content-stretch flex items-center justify-center overflow-clip px-[37px] py-[23px] relative rounded-[inherit] w-full">
        <p className="font-['HYXiaoBoMeiYanTiW:Regular',sans-serif] leading-[normal] not-italic relative shrink-0 text-[24px] text-black text-nowrap tracking-[7.68px]">摆好啦</p>
      </div>
      <div aria-hidden="true" className="absolute border border-black border-solid inset-0 pointer-events-none rounded-[32px]" />
    </motion.button>
  );
}

interface OfferingStageProps {
  onComplete: () => void;
}

export default function OfferingStage({ onComplete }: OfferingStageProps) {
  const [revealed, setRevealed] = useState({ left: false, center: false, right: false });

  const allRevealed = revealed.left && revealed.center && revealed.right;

  const handleReveal = (key: 'left' | 'center' | 'right') => {
    if (!revealed[key]) {
      setRevealed(prev => ({ ...prev, [key]: true }));
    }
  };

  return (
    <div className="relative w-[1440px] h-[1024px] bg-white overflow-hidden" data-name="Desktop - 5" style={{ backgroundImage: "linear-gradient(rgba(251, 196, 212, 0) 9.668%, rgb(251, 196, 212) 114.31%), linear-gradient(90deg, rgb(255, 255, 255) 0%, rgb(255, 255, 255) 100%)" }}>
      <div className="absolute h-[598px] left-[372px] top-0 w-[695px]" data-name="云 1">
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <img alt="" className="absolute h-[116.18%] left-0 max-w-none top-0 w-full" src={img4} />
        </div>
      </div>
      <p className="absolute font-['HYXueJunJ:Regular',sans-serif] leading-[normal] left-[86px] not-italic text-[256px] text-nowrap text-white top-[256px] tracking-[81.92px]">老爷保号</p>
      <div className="absolute left-1/2 size-[464px] top-[71px] translate-x-[-50%]" data-name="老爷像 1">
        <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none size-full" src={img5} />
      </div>
      <p className="absolute font-['HYXiaoBoMeiYanTiW:Regular',sans-serif] leading-[normal] left-[101px] not-italic text-[36px] text-black text-nowrap top-[52px] tracking-[4.32px]">老爷</p>
      
      <Avatar />
      <StatusDot />

      {/* Left Offering Circle */}
      <div 
        onClick={() => handleReveal('left')}
        className={`absolute bg-white left-[303px] overflow-clip rounded-[100px] shadow-[0px_4px_32px_0px_white] size-[169px] top-[619px] transition-transform active:scale-95 cursor-pointer ${revealed.left ? '' : 'hover:scale-105'}`}
      >
        <AnimatePresence>
          {revealed.left && (
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              className="size-full relative"
            >
              <LeftOfferingContent />
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Center Offering Circle */}
      <div 
        onClick={() => handleReveal('center')}
        className={`absolute bg-white left-[635px] rounded-[100px] shadow-[0px_4px_32px_0px_white] size-[169px] top-[619px] transition-transform active:scale-95 cursor-pointer ${revealed.center ? '' : 'hover:scale-105'}`}
      >
        <AnimatePresence>
          {revealed.center && (
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              className="size-full relative"
            >
              <CenterOfferingContent />
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Right Offering Circle */}
      <div 
        onClick={() => handleReveal('right')}
        className={`absolute bg-white left-[957px] overflow-clip rounded-[100px] shadow-[0px_4px_32px_0px_white] size-[169px] top-[619px] transition-transform active:scale-95 cursor-pointer ${revealed.right ? '' : 'hover:scale-105'}`}
      >
        <AnimatePresence>
          {revealed.right && (
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              className="size-full relative"
            >
              <RightOfferingContent />
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {!allRevealed && (
        <p className="absolute font-['HYXiaoBoMeiYanTiW:Regular',sans-serif] leading-[normal] left-[calc(50%-218px)] not-italic text-[24px] text-black text-nowrap top-[847px] tracking-[7.68px] animate-pulse">
          “后生仔，虔诚的摆上贡品吧”
        </p>
      )}

      {allRevealed && <DoneButton onClick={onComplete} />}
    </div>
  );
}
