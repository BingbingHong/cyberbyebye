import { useState } from "react";
import OfferingStage from "./components/OfferingStage";
import WishingStage from "./components/WishingStage";
import IncenseStage from "./components/IncenseStage";
import BurningStage from "./components/BurningStage";
import FinalStage from "./components/FinalStage";
import { FitScreen } from "./components/ui/FitScreen";
import { Toaster, toast } from "sonner";

type Stage = 'offering' | 'wishing' | 'incense' | 'burning' | 'final';

export default function App() {
  const [stage, setStage] = useState<Stage>('offering');

  const handleOfferingComplete = () => {
    setStage('wishing');
  };

  const handleWishSend = (wish: string) => {
    if (!wish.trim()) {
      toast.error("许个愿吧！");
      return;
    }
    
    // console.log("Wish sent:", wish);
    toast.success("愿望已发送给老爷！");
    
    setTimeout(() => {
        setStage('incense');
    }, 1000);
  };

  const handleIncenseComplete = () => {
    setStage('burning');
  };

  const handleBurningComplete = () => {
    setStage('final');
  };

  return (
    <div className="w-full h-screen overflow-hidden bg-[#fafafa]">
      <FitScreen width={1440} height={1024}>
        {stage === 'offering' && <OfferingStage onComplete={handleOfferingComplete} />}
        {stage === 'wishing' && <WishingStage onSend={handleWishSend} />}
        {stage === 'incense' && <IncenseStage onComplete={handleIncenseComplete} />}
        {stage === 'burning' && <BurningStage onComplete={handleBurningComplete} />}
        {stage === 'final' && <FinalStage />}
      </FitScreen>
      <Toaster />
    </div>
  );
}
